public interface ProductState {
    void next(Product prod);
    void previous(Product prod);
}
