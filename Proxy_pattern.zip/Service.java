public interface Service {
    void downloadFile();
}
