public class TowerComputer extends AbstractComputer {

}
