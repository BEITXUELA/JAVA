public class Report {
    private String name;

    public void generate(){
        System.out.println("Report is being generated.");
        System.out.println("..........................");
        System.out.println("Report has been generated.");
    }

}
