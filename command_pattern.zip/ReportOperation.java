public interface ReportOperation {
    void execute();
}
