public class ReportGenerationExecutor {

    public void executeOperation(ReportOperation reportOperation){
        reportOperation.execute();
    }
}
