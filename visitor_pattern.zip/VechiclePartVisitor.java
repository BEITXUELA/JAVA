public interface VechiclePartVisitor {
    void visit(VehiclePart vehiclePart);
}
