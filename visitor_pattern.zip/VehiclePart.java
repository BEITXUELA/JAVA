public interface VehiclePart {
    void accept(VechiclePartVisitor vechiclePartVisitor);
}
