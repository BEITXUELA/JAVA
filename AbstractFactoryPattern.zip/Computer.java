public interface Computer {

    void compute();
}
