public interface Handler {

    void handleRequest();
}
