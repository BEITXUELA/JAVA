public interface Worker {
    void performTask();
}
