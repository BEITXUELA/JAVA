public interface Colour {

}
