public abstract class Store {
    public abstract Colour getColour();
}
