public interface Machine {
    void performOperation();
}
