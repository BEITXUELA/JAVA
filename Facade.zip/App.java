public class App {
    public static void main(String[] args) {
        FacadeClass facadeClass = new FacadeClass();

        facadeClass.computerPerformOperation();
        facadeClass.robotPerformOperation();
    }
}
