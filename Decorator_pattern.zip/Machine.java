public interface Machine {
    String doOperation();
}
