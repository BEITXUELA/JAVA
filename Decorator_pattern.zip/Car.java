public class Car implements Machine {
    @Override
    public String doOperation() {
        return "Car";
    }
}
